﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ProjektX
{
    public partial class Form3 : Form
    {
        public Form1 mother;
        public Form3(Form1 mother)
        {
            this.mother = mother;
            InitializeComponent();
        }
        string WhatCalculation = "";
        double CalculationResult = 0;
        double length1 = 0;



        private void button1_Click(object sender, EventArgs e)
        {
            WhatCalculation = "surface";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            WhatCalculation = "scope";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            {
                try
                {
                    length1 = Convert.ToDouble(textBox3.Text);




                    switch (WhatCalculation)
                    {
                        case "scope":
                            CalculationResult = 2 * length1 + 2 * length1;
                            MessageBox.Show($"The scope of your square is: {CalculationResult}");
                            break;
                        case "surface":
                            CalculationResult = length1 * length1;
                            MessageBox.Show($"The surface of your square is: {CalculationResult}");
                            break;
                        default:



                            break;
                    }
                }
                catch
                {
                    MessageBox.Show("One of the input values is not a number!");
                }
            }
            }

        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void Form3_FormClosed(object sender, FormClosedEventArgs e)
        {
            mother.Show();
        }
    }
}
