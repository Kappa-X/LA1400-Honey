﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace Rectangle_Forms
{
    public partial class Form4 : Form
    {
        string WhatCalculation = "";
        double CalculationResult = 0;
        int length1 = 0;
        int length2 = 0;



        public Form4()
        {
            InitializeComponent();
        }



        private void Form1_Load(object sender, EventArgs e)
        {



        }



        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            WhatCalculation = "scope";
        }



        private void button1_Click(object sender, EventArgs e)
        {
            WhatCalculation = "surface";
        }



        private void textBox1_TextChanged(object sender, EventArgs e)
        {



        }



        private void textBox2_TextChanged(object sender, EventArgs e)
        {



        }



        private void button3_Click(object sender, EventArgs e)
        {
            length1 = Convert.ToInt32(textBox3.Text);
            length2 = Convert.ToInt32(textBox1.Text);



            switch (WhatCalculation)
            {
                case "scope":
                    CalculationResult = 2 * length1 + 2 * length2;
                    MessageBox.Show($"The scope of your rectangle is: {CalculationResult}");
                    break;
                case "surface":
                    CalculationResult = length1 * length2;
                    MessageBox.Show($"The surface of your rectangle is: {CalculationResult}");
                    break;
                default:
                    MessageBox.Show("You haven't defined the lengths!");
                    break;
            }
        }
    }
}