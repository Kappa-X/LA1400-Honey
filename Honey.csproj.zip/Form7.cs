﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ProjektX
{
    public partial class Form7 : Form
    {
        public Form1 mother;
        public Form7(Form1 mother)
        {
            this.mother = mother;
            InitializeComponent();
        }
        string WhatCalculation = "";
        double CalculationResult = 0;
        int length1 = 0;
        int length2 = 0;
        private void button2_Click(object sender, EventArgs e)
        {
            WhatCalculation = "scope";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            WhatCalculation = "surface";
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            length1 = Convert.ToInt32(textBox3.Text);
            length2 = Convert.ToInt32(textBox1.Text);



            switch (WhatCalculation)
            {
                case "scope":
                    CalculationResult = 2 * length1 + 2 * length2;
                    MessageBox.Show($"The scope of your rectangle is: {CalculationResult}");
                    break;
                case "surface":
                    CalculationResult = length1 * length2;
                    MessageBox.Show($"The surface of your rectangle is: {CalculationResult}");
                    break;
                default:
                    MessageBox.Show("You haven't defined the lengths!");
                    break;
            }
        }

        private void Form7_Load(object sender, EventArgs e)
        {

        }

        private void Form7_FormClosed(object sender, FormClosedEventArgs e)
        {
            mother.Show();
        }
    }
}
