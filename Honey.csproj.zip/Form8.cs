﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ProjektX
{
    public partial class Form8 : Form
    {
        public Form1 mother;
        public string WantedCalculation = "";
        public int length1;
        public int length2;
        public int length3;
        public int height;
        public Form8(Form1 mother)
        {
            this.mother = mother; 
            InitializeComponent();
        }

        private void Form8_Load(object sender, EventArgs e)
        {

        }

        private void Form8_FormClosed(object sender, FormClosedEventArgs e)
        {
            mother.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            WantedCalculation = "Scope";
            label1.Text = "You have chosen scope";
            length2 = 0;
            length3 = 0;
            label7.Visible = false; //height
            textBox4.Visible = false; //height input

            label4.Visible = true; // Length 1
            textBox3.Visible = true; // Length 1 input

            label5.Visible = true; // Length 2
            textBox1.Visible = true; // Lenght 2 input

            label6.Visible = true; // Lenght 3
            textBox2.Visible = true; // Length 3 input
        }

        private void button1_Click(object sender, EventArgs e)
        {
            WantedCalculation = "Surface";
            label1.Text = "You have chosen surface";
            label7.Visible = true; //height
            textBox4.Visible = true; //height input

            label4.Visible = true; // Lenght 1
            textBox3.Visible = true; // Length 1 input

            label5.Visible = false; // Length 2
            textBox1.Visible = false; // Length 2 input

            label6.Visible = false; // Length 3
            textBox2.Visible = false; // Length 3 input
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            height = Convert.ToInt32(textBox4.Text);
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            length1 = Convert.ToInt32(textBox3.Text);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            length2 = Convert.ToInt32(textBox1.Text);
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            length3 = Convert.ToInt32(textBox2.Text);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            double Result;


            if (WantedCalculation == "Surface")
            {
                Result = length1 * height / 2;
                MessageBox.Show("" + Result + "");
            }
            else if (WantedCalculation == "Scope")
            {
                Result = length1 + length2 + length3;
                MessageBox.Show("" + Result + "");
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }
    }
}
