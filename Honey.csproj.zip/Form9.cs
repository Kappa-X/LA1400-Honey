﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ProjektX
{
    public partial class Form9 : Form
    {
        public Form1 mother;
        public Form9(Form1 mother)
        {
            this.mother = mother;
            InitializeComponent();
        }
        string WhatCalculation = "";
        double CalculationResult = 0;
        double length1 = 0;
        double length2 = 0;
        double length3 = 0;


        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            {
                try
                {
                    length1 = Convert.ToInt32(textBox3.Text);
                    length2 = Convert.ToInt32(textBox1.Text);
                    length3 = Convert.ToInt32(textBox2.Text);




                    switch (WhatCalculation)
                    {
                        case "edge length":
                            CalculationResult = length1 * 4 + length2 * 4 + length3 * 4;
                            MessageBox.Show($"The edge length of your cuboid is: {CalculationResult}");
                            break;
                        case "surface":
                            CalculationResult = (length1 * length2 * 2) + (length2 * length3 * 2) + (length3 * length2 * 2);
                            MessageBox.Show($"The surface of your cuboid is: {CalculationResult}");
                            break;
                        case "volume":
                            CalculationResult = length1 * length2 * length3;
                            MessageBox.Show($"The volume of your cuboid is: {CalculationResult}");
                            break;
                        default:
                            break;
                    }
                }
                catch
                {
                    MessageBox.Show("One of the input values is not a number!");
                }
            }
            }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            WhatCalculation = "surface";
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void button5_Click(object sender, EventArgs e)
        {
            WhatCalculation = "volume";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            WhatCalculation = "edge length";
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form9_Load(object sender, EventArgs e)
        {

        }

        private void Form9_FormClosed(object sender, FormClosedEventArgs e)
        {
            mother.Show();
        }
    }
}
