﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ProjektX
{
    public partial class Form2 : Form
    {
        public Form1 mother;
        public Form2(Form1 mother)
        {
            this.mother = mother;
            InitializeComponent();
        }
        string WhatCalculation = "";
        double CalculationResult = 0;
        int radius = 0;
        private void button2_Click(object sender, EventArgs e)
        {
            WhatCalculation = "scope";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            WhatCalculation = "surface";
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            radius = Convert.ToInt32(textBox1.Text);

            switch (WhatCalculation)
            {
                case "scope":
                    double r2 = radius * radius;
                    CalculationResult = r2 * Math.PI;
                    MessageBox.Show($"The scope of your circle is: {CalculationResult}");
                    break;
                case "surface":
                    double d = radius * 2;
                    CalculationResult = Math.PI * d;
                    MessageBox.Show($"The surface of your circle is: {CalculationResult}");
                    break;
                default:
                    MessageBox.Show("You haven't defined the radius!");
                    break;
            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void Form2_FormClosed(object sender, FormClosedEventArgs e)
        {
            mother.Show();
        }
    }
}
